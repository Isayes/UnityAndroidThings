# DemoRecyclerView
My Android Demo for RecylerView
<br />**第一关：先利用RecyclerView创建一个listview并自定义分割线**

<br />要先简单知道**RecyclerView是什么**:  http://blog.nicerdata.com/archives/1861

<br />`实现de效果图`<br />


![最终效果](https://raw.githubusercontent.com/Isayes/RecyclerViewPractice/6b97e3947ab84bc8309690439d5cf96a45e88441/screenshot.gif)
