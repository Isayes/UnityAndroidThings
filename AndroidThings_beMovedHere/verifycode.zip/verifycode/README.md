# verifycode
一个简单的验证码制作

##实现效果演示
![效果演示](https://raw.githubusercontent.com/Isayes/verifycode/d3b8d69367c420e78c1b9b6ca98606b55e067ee1/Pic/gif.gif)
