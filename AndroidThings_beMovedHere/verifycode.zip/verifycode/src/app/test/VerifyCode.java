package app.test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class VerifyCode
 */
@WebServlet("/verifycode")
public class VerifyCode extends HttpServlet {

	static String s = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VerifyCode() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		BufferedImage bi = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);//����ͼ�񻺳��� ���캯��

		Graphics g = bi.getGraphics();//ͨ��ͼ�񻺳������ͼ�����
		String rand = "";
		Random random = new Random();

		g.setColor(new Color(200, 200, 200));
		g.fillRect(0, 0, 100, 100);

		for (int i = 0; i < 4; i++) {
			rand += s.charAt(random.nextInt(s.length()));
		}
		g.setColor(new Color(random.nextInt(110), random.nextInt(200), random.nextInt(200)));
		for (int i = 0; i < 10; i++) {
			g.drawLine(random.nextInt(100), random.nextInt(100), random.nextInt(10) + 85, random.nextInt(10) + 85);
		}

		g.setColor(Color.RED);
		g.drawString(rand, 30, 30);
		request.getSession().setAttribute("rand", rand);
		ImageIO.write(bi, "jpg", response.getOutputStream());// ���͸������

	}
}
