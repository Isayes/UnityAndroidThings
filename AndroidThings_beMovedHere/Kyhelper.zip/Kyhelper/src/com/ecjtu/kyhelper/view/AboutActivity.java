package com.ecjtu.kyhelper.view;

import com.ecjtu.kyhelper.R;

import android.app.Activity;
import android.os.Bundle;

/**
 * TODO : AboutActivity.java--���ڱ������ļ��
 * 
 * @author ECJTU IsayesHu
 * @date 2015��3��29��
 */
public class AboutActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
	}

}
