package com.ecjtu.kyhelper.webview;

import android.app.Activity;
import android.os.Bundle;

import com.ecjtu.kyhelper.R;

/**
 * TODO : ������
 * 
 * @author ECJTU IsayesHu
 * @date 2015��3��31��
 */

public class WebviewQiuMaXing extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_qiumaxing);
	}

}
