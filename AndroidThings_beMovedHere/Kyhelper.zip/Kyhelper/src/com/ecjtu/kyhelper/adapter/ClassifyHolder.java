package com.ecjtu.kyhelper.adapter;

import android.widget.TextView;

/**
 * TODO : ��ͼ
 * 
 * @author ECJTU IsayesHu
 * @date 2015��4��3��
 */
public class ClassifyHolder {

	public TextView tvClassifyName;
	public TextView tvClassifyType;
	public TextView tvClassifyLoc;

}
