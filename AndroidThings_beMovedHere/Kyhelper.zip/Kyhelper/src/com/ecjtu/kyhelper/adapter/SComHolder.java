package com.ecjtu.kyhelper.adapter;

import android.widget.TextView;

public class SComHolder {
	
	public TextView tvComUser;
	public TextView tvComContent;

}
