package com.ecjtu.kyhelper;

import android.app.Activity;
import android.os.Bundle;
/**
 * TODO : This file is useless.
 * @author ECJTU IsayesHu
 * 2015��3��26��
 */
public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
}
