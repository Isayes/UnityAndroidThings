---
title: "# 读 Android 开发艺术探索 &10"
categories: 
- notes
- android
date: 2016-05-10 18:41:31
tags:
---

关键词：四大组件 / Activity / Service / BroadcastReceiver / ContentProvider

本次笔记主要梳理了四大组件的进一步认识，为今后更进一步了解四大组件的工作原理做个准备，温故知新、查漏补缺。

<!--more-->

Android 四大组件中除了 BroadcastReceiver 以外，其它三种组件都必须只在 AndroidManifest 中注册，而 BroadcastReceiver 既可以在 Manifest 中注册也可以通过代码来注册。Activity、Service、BroadcastReceiver 需要借助 Intent 来调用，而 ContentProvider 无需借助 Intent。

## 1. Activity # #

1. Activity 是一个展示型的组件；
2. Activity 的启动由 Intent 来触发，其中 Intent 分为显示和隐式，显示 Intent 可以明确地指向一个 Activity 组件，隐式 Intent 则指向一个或多个目标 Activity 甚至没有任何一个 Activity 组件可以处理这个隐式 Intent；
3. Activity 组件的主要作用是展示一个界面并和用户交互，扮演着前台界面的角色；
4. Activity 只有一种运行模式，即 Activity 处于启动状态；

## 2. Service # #

1. Service 是一种计算型组件，用于后台执行一系列计算任务；
2. Service 组件工作在后台，用户无法感知；
3. Service 组件不同于 Activity，它有两种状态：启动状态 和 绑定状态；
4. Service 处于启动状态的时候，Service 内部做一些后台计算，不需和外界有直接的交互。不过，Service 组件本身是运行在主线程中的，耗时的后台计算仍然需要在单独的线程中去完成；
5. Service 处于绑定状态的时候，Service 内部同样可以做一些后台计算，并且可以很方便地和 Service 组件进行通信；
6. 停止一个 Service 需要灵活采用 stopService 和 unBindService 这两个方法才能完全停止一个 Service 组件；

强调一下 Service 的两种状态：  
启动状态 —— 主要用于执行后台计算；  
绑定状态 —— 主要用于其它组件和 Service 的交互；  
这两种状态是可以共存的，既可以处于启动状态也可以同时处于绑定状态。  

```java
Intent intentService = new Intent(this, MyService.class);
startService(intentService);
```

```java
Intent intentService = new Intent(this, MyService.class);
bindService(intentService, mServiceConnection, BIND_AUTO_CREATE);
```

来了解一下 Google 官方的说明：  

对于 startService：   
Once started, a service can run in the background indefinitely, even if the component that started it is destroyed. Usually, a started service performs a single operation and does not return a result to the caller. For example, it might download or upload a file over the network. When the operation is done, the service should stop itself.   
用 startService 启动，这个 Service 不会跟随者启动它的 component 消减，而且原则上不能与 UI 互动；

对于 bindService：  
A bound service offers a client-server interface that allows components to interact with the service, send requests, get results, and even do so across processes with interprocess communication (IPC). A bound service runs only as long as another application component is bound to it. Multiple components can bind to the service at once, but when all of them unbind, the service is destroyed.  
用 bindService 的情况下，此 service 可以跟 component 进行沟通，甚至可以做到 IPC

小结：  
bindService 和 startService 最主要的差别在于其本身的 LifeCycle 以及 bindService 可以用来做 IPC（可以让你的 service 和 UI 沟通）


## 3. BroadcastReceiver # #

1. BroadcastReceiver 是一种消息型组件；
2. BroadcastReceiver 用于在不同的组件乃至不同的应用之间传递消息；
3. 工作在系统内部，用户不感知；
4. BroadcastReceiver 有两种注册的方式：静态注册 和 动态注册；
5. 静态注册在 manifest 里注册广播，在应用安装时就会被系统解析，不需要应用启动就可以收到相应广播；
6. 动态注册通过 Context.registerReceiver() 来实现，不需要时通过 Context.unRegisterReceiver() 来解除广播，这种注册方式必须要应用启动才能注册并接收广播；
7. 通过 Context 的一系列 send 方法来发送广播，被发送的广播会被系统发送给感兴趣的广播接受者，发送和接收过程的匹配是通过广播接受者的 <intent-filter> 来描述的；
8. BroadcastReceiver 不适合用来执行耗时的操作；
9. BroadcastReceiver 没有停止的概念，不需要停止；

当通过 send 方法来发送广播的时候，AMS 会查找出匹配的广播接收者并将广播发送给它们处理。  
广播发送的几种类型有：普通广播、有序广播和粘贴广播；它们的发送/接收过程是类似的；  


## 4. ContentProvider # #

1. ContentProvider 是一种数据共享型组件，通过 Binder 用于向其它组件乃至其它应用共享数据；
2. ContentProvider 无法被用户感知，不需要手动停止；
3. ContentProvider 的内部需要实现 增 删 改 查 这四种操作；
4. ContentProvider 内部维持着一份数据集合，可以通过数据库、List、Map 等来实现；
5. ContentProvider 内部的 insert / delete / update / query 方法需要处理好线程同步，因为这几个方法是在 Binder 线程池中被调用


当 ContentProvider 所在的进程启动的时候，ContentProvider 的 onCreate 要先于 Application 的 onCreate 而执行，这在四大组件中是一个很少有的现象；

End.

Note by [HF](http://isayes.github.io).  
Learn from 《Android 开发艺术探索》

---

