---
title: "# 读 Android 开发艺术探索 &5"
categories: 
- notes
- android
date: 2016-05-05 15:29:44
tags:
---

关键词：Binder 连接池 / BinderPool / AIDL / Service /

AIDL 是最常用的进程间通信方式，先温故一下它的大致流程：（1）创建一个 Service 和一个 AIDL 接口；（2）创建一个类，继承于 AIDL 接口中的 Stub 类，并实现 Stub 中的抽象方法；（3）在 Service 中的 onBind 方法中返回这个类的对象；（4）客户端绑定服务端的 Service，建立连接后访问远程服务端；<!--more-->

## 正文 # #

本次笔记的梳理主要是有关 Binder 连接池，需要知道以下几点：

1. 随着 AIDL 数量的增加，我们并不能无限制的增加 Service，作为四大组件之一的 Service 本身也是一种系统资源，我们需要减少 Service 的数量，将所有的 AIDL 放在同一个 Service 中去管理；
2. Binder 连接池的主要作用就是将每个业务模块的 Binder 请求统一转发到远程 Service 中去执行，从而避免了重复创建 Service 的过程；
3. 只需要创建一个 Service 即可完成多个 AIDL 接口的工作；
4. BinderPool 是一个单例实现，在同一个进程中只会初始化一次，所以提前初始化 BinderPool，可以优化程序的体验，比如放在 Application 里面；
5. BinderPool 中有断线重连的机制，当远程服务意外终止时，BinderPool 会重新建立连接；
6. BinderPool 能够极大的提高 AIDL 的开发效率，并且可以避免大量的 Service 创建，因此，建议在 AIDL 开发工作中引入 BinderPool 机制；

End.

Note by [HF](http://isayes.github.io).  
Learn from 《Android 开发艺术探索》

---

本文标签：[Android](http://isayes.github.io/categories/android)
