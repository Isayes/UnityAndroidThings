---
title: "# 读 Android 开发艺术探索 &9"
categories: 
- notes
- android
date: 2016-05-09 11:35:52
tags:
---

关键词：View 动画 / 帧动画 / 属性动画

Android 动画分为三种：View 动画、帧动画和属性动画。本次笔记初步梳理了跟 Android 动画相关的基本知识点，便于今后温故知新，查漏补缺。
<!--more-->

## 1. View 动画 # #

需要知道的几点：

1. View 动画的作用对象是 View；
2. 只支持 4 种类型：平移（Translate）TranslateAnimation、旋转（Rotate）RotateAnimation、缩放（Scale）ScaleAnimation、不透明度（Alpha）AlphaAnimation；
3. 虽然帧动画也属于 View 动画，但是其表现形式与以上四种的变换效果不同；
4. View 动画建议采用 XML 来定义动画，XML 的可读性比较好；
5. 使用 View 动画的特殊场景：ViewGroup 中可以控制子元素的出场效果，在 Activity 中可以实现不同 Activity 之间的切换效果；
6. LayoutAnimation 也是一个 View 动画，作用于 ViewGroup，常常被用在 ListView 上；
7. Activity 可以自定义切换效果，主要用到 overridePendingTranslation(int enterAnim, int exitAnim) 方法，需要在 startActivty(Intent) 或者 finish() 之后调用它才能生效；

PS 帧动画：  
帧动画其实也属于 View 动画，但是不同的是系统提供了另一个类 AnimationDrawable 来使用帧动画，顺序播放一组实现预定义好的图片。比较简单但是容易引起 OOM。

## 2. 属性动画 # #

需要知道的几点：

1. 对作用对象进行了扩展，属性动画可以对任何对象做动画，甚至还可以没有对象；想要实现比较绚丽的动画，需要知道：ValueAnimator、ObjectAnimator 和 AnimatorSet 这三个动画类，其中 ObjectAnimator 继承自 ValueAnimator，AnimatorSet 是动画集合可以定义一组动画；
2. 属性动画默认的时间间隔是 300 ms，默认帧率 10 ms/帧;
3. 属性动画可以达到的效果是：在一个时间间隔内，完成对象从一个属性值到另一个属性值的改变，几乎是无所不能的；
4. 实际开发中建议使用代码的方式来实现属性动画，因为更简单并且通过代码动态地创建属性动画；
5. 属性动画的工作原理：  
要求动画作用的对象提供该属性的 set 方法，属性动画根据你传递的该属性初始值和最终值，以动画的效果多次去调用 set 方法。每次传递给 set 方法的值都不一样，确切来说是随着时间的推移，所传递的值越来越接近最终值；
6. 属性动画中的插值器（Interpolator）和估值器（TypeEvaluator）很重要，是实现非匀速动画的重要手段；插值器的作用是根据当前时间流逝的百分比来计算出当前属性值改变的百分比。估值器的作用是根据当前属性改变的百分比来计算改变后的属性值；
7. 属性动画要求该属性有 set 方法和 get 方法（可选）
8. 可以自定义插值器和估值器，它们都是一个接口，且内部都只有一个方法，我们只要派生一个类实现接口就可以了，然后就可以做出千奇百怪的效果；
9. 属性动画需要运行在 Looper 的线程里；

## 3. 使用动画需要特别注意的几点 # #

1. OOM 问题。尽量避免使用帧动画；
2. 内存泄漏问题。属性动画中有一类是无限循环的动画，需要在 Activity 的退出时及时停止，否则导致 Activity 无法释放而造成内存泄漏，View 动画不存在这个问题；
3. View 动画是对 View 的影像做动画，并不是真的改变 View 的状态，防止 setVisibility(View.GONE) 失效，只需要调用 view.clearAnimation() 清除 View 动画即可解决此问题；
4. 尽量使用 dp，使用 px 会导致在不同的设备上有不同的效果；
5. 建议使用动画的过程中，开启硬件加速提高动画的流畅性；


End.

Note by [HF](http://isayes.github.io).  
Learn from 《Android 开发艺术探索》

---

