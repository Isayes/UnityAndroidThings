---
title: "# 读 Android 开发艺术探索 &7"
categories: 
- notes
- android
date: 2016-05-07 13:48:06
tags:
---

关键词：自定义 View

自定义 View 是一个综合的技术体系，涉及 View 的层次结构、事件分发机制、View 的工作原理等技术细节。面对陌生的自定义 View 的时候，运用以下思想去快速的解决问题：首先掌握了基本功比如 View 的弹性滑动、滑动冲突、绘制原理等；熟练掌握了基本功之后，在面对新的自定义 View 的时候，要能对其进行分类并选择合适的实现思路；平时多积累一些自定义 View 相关的经验，并逐渐做到融会贯通。

<!--more-->

## 1. 自定义 View 的分类 # #

- 继承 View 重写 onDraw 方法。用于实现一些不规则的效果，需要自己支持 wrap_content 和 padding；
- 继承 ViewGroup 派生特殊的 Layout。用于自定义的布局，重新定义一种新布局，需要合适地处理 ViewGroup 的测量、布局这两个过程，并同时处理子元素的测量和布局过程；
- 继承特定的 View 比如 TextView。用于拓展某种已有的 View 的功能；
- 继承特定的 ViewGroup 比如 LinearLayout。几种 View 组合在一起的效果；

## 2. 自定义 View 需要知道的几点 # #

- 让 View 支持 wrap_content。对于直接继承自 View 的控件，如果不对 wrap_content 做特殊处理，那么就相当于使用 match_parent。需要指定一个 wrap_content 模式的默认宽高即可；
- 如果有必要，让 View 支持 padding。直接继承 View 和 ViewGroup 的控件，padding 是默认无法生效的，需要自己处理；（中心思想就是要考虑到 View 四周的空白）
- 尽量不要在 View 中使用 Handler，没必要；View 本身就提供了 post 系列的方法，完全替代 Handler 的作用；
- View 中如果有线程或动画需要停止的时候，那么 View#onDetachedFromWindow 是一个很好的时机；
- 处理冲突

End.

Note by [HF](http://isayes.github.io).  
Learn from 《Android 开发艺术探索》

---

本文标签：[Android](http://isayes.github.io/categories/android)
