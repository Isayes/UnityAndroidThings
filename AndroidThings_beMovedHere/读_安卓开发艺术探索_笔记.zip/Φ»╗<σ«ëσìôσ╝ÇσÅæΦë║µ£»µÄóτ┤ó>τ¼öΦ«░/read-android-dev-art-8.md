---
title: "# 读 Android 开发艺术探索 &8"
categories: 
- notes
- android
date: 2016-05-08 11:32:52
tags:
---

关键词：RemoteViews / 通知栏 / 桌面小部件 /

RemoteViews 是一种远程 View，是一种远程服务，实际上和远程 Service 是一样的，RemoteViews 是一个 View 结构，可以在其它进程中显示，提供了一组操作用于跨进程更新它的界面。RemoteViews 在 Android 中的使用场景有两种：通知栏 和 桌面小部件。

<!--more-->

通知栏和桌面小部件的开发过程都需要用到 RemoteViews，在更新界面时无法像在 Activity 里面那样去直接更新 View，因为二者的界面都运行在其它进程中，即系统的 SystemServer 进程；为了跨进程更新界面，RemoteViews 提供了一系列 set 方法，并且这些方法只是 View 全部方法的子集，RemoteViews 中所支持的 View 类型也是有限的

## 1. 通知栏 # #

通知栏主要是通过 NotificationManager 的 notify 方法来实现，除了默认效果还可以自定义。

系统默认的样式很简单：  

```java
Notification notification = new Notification();
notification.icon = R.drawable.ic_launcher;
notification.tickerText = "hello world";
notification.when = System.currentTimeMillis();
notification.flags = Notification.FLAG_AUTO_CANCEL;
Intent intent = new Intent(this, DemoActivity.class);
PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
notification.setLatestEventInfo(this, "hello", "this is a notification.", pendingIntent);
NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
manager.notify(1, notification);
```

自定义的样式也很简单，通过 RemoteViews 加载这个布局文件：  

```java
Notification notification = new Notification();
notification.icon = R.drawable.ic_launcher;
notification.tickerText = "hello world";
notification.when = System.currentTimeMillis();
notification.flags = Notification.FLAG_AUTO_CANCEL;
Intent intent = new Intent(this, DemoActivity.class);
/ 'PendingIntent 表示的是一种待定的 Intent，这个 Intent 中所包含的意图必须由用户来触发'
PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.layout_notification);
remoteViews.setTextViewText(R.id.msg, "hello");
remoteViews.setImageResource(R.id.icon, R.drawable.icon);
PendingIntent openActivity2PendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, DemoActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
remoteViews.setOnClickPendingIntent(R.id.open_activity2, openActivity2PendingIntent);
notification.contentView = remoteViews;
notification.contentIntent = pendingIntent;

NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
manager.notify(2, notification);
```



## 2. 桌面小部件 # #

桌面小部件通过 AppWidgetProvider 来实现，本质上是一个广播组件，，因此必须要注册；

```java
<receiver
    android:name=".MyAppWidgetProvider" >
    <meta-data
        android:name="android.appwidget.provider"
        android:name="@xml/appwidget_provider_info" >
    </meta-data>

    <intent-filter>
        <action android:name="io.github.isayes.action.CLICK" />
        <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
    </intent-filter>
</receiver>
```

开发步骤;  
- 定义小部件界面
- 定义小部件配置信息
- 定义小部件的实现类
- 在 Manifest 文件中声明小部件

## 3. 关于 PendingIntent 需要知道的几点 # #

1. 表示一种 pending 状态的意图，待定、等待、即将发生的意思；
2. PendingIntent 是在将来的某个不确定的时刻发生的，而 Intent 是立即发生；
3. 典型使用场景是给 RemoteViews 添加单击事件，通过 send 和 cancel 方法来发送和取消特定的待定 Intent；
4. 支持三种待定意图：启动 Activity、启动 Service 和发送广播；
5. RemoteViews 并不支持所有的 View 类型，具体的《技术探索》P230；
6. 没有提供 findViewById 方法，无法直接访问里面的 View 元素，而必须通过 RemoteViews 所提供的一系列 set 方法来完成，因为 RemoteViews 在远程进程中显示，没办法直接 findViewById；
7. 事实上，大部分 set 方法是通过反射来完成的；
8. RemoteViews 实现了 Parcelable 接口；
9. 关于单击事件，RemoteViews 中只支持发起 PendingIntent，不支持 onClickListener 的模式；

Not End.

Note by [HF](http://isayes.github.io).  
Learn from 《Android 开发艺术探索》
