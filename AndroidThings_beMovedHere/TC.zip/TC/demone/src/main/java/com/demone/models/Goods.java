package com.demone.models;

/**
 * Author: HF
 * Date:   2016-03-18
 * Description:
 */

public class Goods {
    public int userId;
    public String userName;
}
