package com.demone.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.demone.R;
import com.demone.models.Goods;
import com.tubb.smrv.SwipeMenuLayout;
import com.tubb.smrv.SwipeMenuRecyclerView;

import java.util.List;

/**
 * Author: HF
 * Date:   2016-03-18
 * Description:
 */

public class AppAdapter2 extends RecyclerView.Adapter {

    private Context mContext;
    private List<Goods> mGoodsList;
    private static final int VIEW_TYPE_ENABLE = 0;
    private static final int VIEW_TYPE_DISABLE = 1;
    private AppAdapter2 mAdapter;
    private SwipeMenuRecyclerView mRecyclerView;

    public AppAdapter2(Context context, List<Goods> mGoodsList) {
        this.mGoodsList = mGoodsList;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(mContext).inflate(R.layout.item_simple, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        Goods user = mGoodsList.get(position);
        if(user.userId % 2 == 0){
            return VIEW_TYPE_DISABLE;
        }else{
            return VIEW_TYPE_ENABLE;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {

        final Goods user = mGoodsList.get(position);
        final MyViewHolder myViewHolder = (MyViewHolder)holder;
        SwipeMenuLayout itemView = (SwipeMenuLayout) myViewHolder.itemView;
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, "Hi " + user.userName, Toast.LENGTH_SHORT).show();
            }
        });
        myViewHolder.btGood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(myViewHolder.itemView.getContext(), "Good", Toast.LENGTH_SHORT).show();
            }
        });
        myViewHolder.btOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, "Open " + user.userName, Toast.LENGTH_SHORT).show();
            }
        });
        myViewHolder.btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGoodsList.remove(holder.getAdapterPosition());
                mAdapter.notifyItemRemoved(holder.getAdapterPosition());
            }
        });
        myViewHolder.tvName.setText(user.userName);
        boolean swipeEnable = swipeEnableByViewType(getItemViewType(position));
        myViewHolder.tvSwipeEnable.setText(swipeEnable ? "swipe on" : "swipe off");

        /**
         * optional
         */
        itemView.setSwipeEnable(swipeEnable);
        itemView.setOpenInterpolator(mRecyclerView.getOpenInterpolator());
        itemView.setCloseInterpolator(mRecyclerView.getCloseInterpolator());
    }

    private boolean swipeEnableByViewType(int viewType) {
        if(viewType == VIEW_TYPE_ENABLE) return true;
        else if(viewType == VIEW_TYPE_DISABLE) return false;
        else return true; // default
    }

    @Override
    public int getItemCount() {
        return mGoodsList.size();
    }

    private class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView tvSwipeEnable;
        View btGood;
        View btOpen;
        View btDelete;

        public MyViewHolder(View itemView) {
            super(itemView);
            tvName = (TextView) itemView.findViewById(R.id.tvName);
            tvSwipeEnable = (TextView) itemView.findViewById(R.id.tvSwipeEnable);
            btGood = itemView.findViewById(R.id.btGood);
            btOpen = itemView.findViewById(R.id.btOpen);
            btDelete = itemView.findViewById(R.id.btDelete);
        }
    }
}
