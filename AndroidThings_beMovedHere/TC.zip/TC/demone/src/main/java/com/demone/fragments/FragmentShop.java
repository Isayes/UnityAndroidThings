package com.demone.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.demone.R;
import com.demone.activitys.ShopDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Author:HF
 * Date:2016-03-17
 */
public class FragmentShop extends Fragment {

    /* 滚动广告 start */
    private ImageView[] imageViews = null;
    private ImageView imageView = null;
    private ViewPager advPager = null;
    private AtomicInteger what = new AtomicInteger(0);
    private boolean isContinue = true;
    /* 滚动广告 end */

    /* 商家列表 start */
    private ListView lv_shop;
    // private List<Shop> mShopList;
    private SimpleAdapter mSimpleAdapter;
    /* 商家列表 end */

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_shop, container, false);
        initViewPager(view);    // 滚动广告区
        initListView(view);     // 商家列表区
        return view;
    }

    /* 滚动广告区 start */
    private void initViewPager(View view) {

        advPager = (ViewPager) view.findViewById(R.id.adv_pager);
        ViewGroup group = (ViewGroup) view.findViewById(R.id.viewGroup);

        List<View> advPics = new ArrayList<>();

        ImageView img1 = new ImageView(getActivity());
        img1.setBackgroundResource(R.mipmap.ad_0);
        advPics.add(img1);

        ImageView img2 = new ImageView(getActivity());
        img2.setBackgroundResource(R.mipmap.ad_1);
        advPics.add(img2);

        ImageView img3 = new ImageView(getActivity());
        img3.setBackgroundResource(R.mipmap.ad_2);
        advPics.add(img3);

        ImageView img4 = new ImageView(getActivity());
        img4.setBackgroundResource(R.mipmap.ad_5);
        advPics.add(img4);

        imageViews = new ImageView[advPics.size()];

        for (int i = 0; i < advPics.size(); i++) {
            imageView = new ImageView(getActivity());
            imageView.setLayoutParams(new ViewGroup.LayoutParams(20, 20));
            imageView.setPadding(5, 5, 5, 5);
            imageViews[i] = imageView;
            if (i == 0) {
                imageViews[i].setBackgroundResource(R.drawable.banner_dian_focus);
            } else {
                imageViews[i].setBackgroundResource(R.drawable.banner_dian_blur);
            }
            group.addView(imageViews[i]);
        }

        advPager.setAdapter(new AdvAdapter(advPics));
        advPager.addOnPageChangeListener(new GuidePageChangeListener());
        advPager.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                    case MotionEvent.ACTION_MOVE:
                        isContinue = false;
                        break;
                    case MotionEvent.ACTION_UP:
                        isContinue = true;
                        break;
                    default:
                        isContinue = true;
                        break;
                }
                return false;
            }
        });

        new Thread(new Runnable() {

            @Override
            public void run() {
                while (true) {
                    if (isContinue) {
                        viewHandler.sendEmptyMessage(what.get());
                        whatOption();
                    }
                }
            }
        }).start();
    }

    private void whatOption() {
        what.incrementAndGet();
        if (what.get() > imageViews.length - 1) {
            what.getAndAdd(-4);
        }
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {

        }
    }

    private final Handler viewHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            advPager.setCurrentItem(msg.what);
            super.handleMessage(msg);
        }

    };

    private final class GuidePageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int arg0) {

        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageSelected(int arg0) {
            what.getAndSet(arg0);
            for (int i = 0; i < imageViews.length; i++) {
                imageViews[arg0].setBackgroundResource(R.drawable.banner_dian_focus);
                if (arg0 != i) {
                    imageViews[i].setBackgroundResource(R.drawable.banner_dian_blur);
                }
            }

        }
    }

    private final class AdvAdapter extends PagerAdapter {
        private List<View> views = null;

        public AdvAdapter(List<View> views) {
            this.views = views;
        }

        @Override
        public int getCount() {
            return views.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(views.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(views.get(position), 0);
            return views.get(position);

        }

        @Override
        public void startUpdate(ViewGroup container) {
            super.startUpdate(container);
        }

        @Override
        public void finishUpdate(ViewGroup container) {
            super.finishUpdate(container);
        }

        @Override
        public Parcelable saveState() {
            return super.saveState();
        }

        @Override
        public void restoreState(Parcelable state, ClassLoader loader) {
            super.restoreState(state, loader);
        }

    }

    /* 滚动广告区 end */


    /* 商家列表 start */
    private void initListView(View view) {

        lv_shop = (ListView) view.findViewById(R.id.lv_shop);
        mSimpleAdapter = new SimpleAdapter(this.getActivity(), getData(), R.layout.shop_lv_item,
                new String[]{"shop_name", "shop_info", "shop_img", "shop_score_icon"},
                new int[]{R.id.tv_shop_name, R.id.tv_shop_info, R.id.iv_shop_img, R.id.iv_score_icon});
        lv_shop.setAdapter(mSimpleAdapter);
        lv_shop.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startActivity(new Intent(getActivity(), ShopDetail.class));
            }
        });
    }

    private List<Map<String, Object>> getData() {
        List<Map<String, Object>> list = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
        map.put("shop_name", "左麻右辣");
        map.put("shop_info", "美食 -- 四号楼");
        map.put("shop_img", R.mipmap.zuo_ma_you_la);
        map.put("shop_score_icon", R.mipmap.shop_score);
        list.add(map);

        map = new HashMap<>();
        map.put("shop_name", "好又多");
        map.put("shop_info", "超市 -- 六号楼");
        map.put("shop_img", R.mipmap.hao_you_duo);
        map.put("shop_score_icon", R.mipmap.shop_score);
        list.add(map);

        map = new HashMap<>();
        map.put("shop_name", "左麻右辣");
        map.put("shop_info", "美食 -- 四号楼");
        map.put("shop_img", R.mipmap.zuo_ma_you_la);
        map.put("shop_score_icon", R.mipmap.shop_score);
        list.add(map);

        map = new HashMap<>();
        map.put("shop_name", "好又多");
        map.put("shop_info", "超市 -- 六号楼");
        map.put("shop_img", R.mipmap.hao_you_duo);
        map.put("shop_score_icon", R.mipmap.shop_score);
        list.add(map);

        map = new HashMap<>();
        map.put("shop_name", "左麻右辣");
        map.put("shop_info", "美食 -- 四号楼");
        map.put("shop_img", R.mipmap.zuo_ma_you_la);
        map.put("shop_score_icon", R.mipmap.shop_score);
        list.add(map);

        map = new HashMap<>();
        map.put("shop_name", "好又多");
        map.put("shop_info", "超市 -- 六号楼");
        map.put("shop_img", R.mipmap.hao_you_duo);
        map.put("shop_score_icon", R.mipmap.shop_score);
        list.add(map);

        return list;

    }
    /* 商家列表 end */

}

