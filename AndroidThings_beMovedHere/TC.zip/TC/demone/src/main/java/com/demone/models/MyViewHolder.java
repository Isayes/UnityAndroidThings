package com.demone.models;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.demone.R;

/**
 * Author: HF
 * Date:   2016-03-18
 * Description:
 */

public class MyViewHolder extends RecyclerView.ViewHolder{
    public TextView tvName;
    public TextView tvSwipeEnable;
    public View btGood;
    public View btOpen;
    public View btDelete;
    public MyViewHolder(View itemView) {
        super(itemView);
        tvName = (TextView) itemView.findViewById(R.id.tvName);
        tvSwipeEnable = (TextView) itemView.findViewById(R.id.tvSwipeEnable);
        btGood = itemView.findViewById(R.id.btGood);
        btOpen = itemView.findViewById(R.id.btOpen);
        btDelete = itemView.findViewById(R.id.btDelete);
    }
}