package com.demone;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

import com.demone.fragments.FragmentOther;
import com.demone.fragments.FragmentShop;
import com.demone.fragments.FragmentTalk;

import java.util.ArrayList;
import java.util.List;

/**
 * Author:HF
 * Date:2016-03-17
 */
public class MainActivity extends FragmentActivity implements View.OnClickListener {

    private ViewPager mViewPager;
    private FragmentPagerAdapter mAdapter;
    private List<Fragment> mFragments;
    private TextView tab_shop;
    private TextView tab_talk;
    private TextView tab_other;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_main);
        initViewAndEvent();
        setTab(0);
    }

    private void initViewAndEvent() {
        mViewPager = (ViewPager) findViewById(R.id.id_viewpager);
        tab_shop = (TextView) findViewById(R.id.id_tab_shop);
        tab_talk = (TextView) findViewById(R.id.id_tab_talk);
        tab_other = (TextView) findViewById(R.id.id_tab_other);
        mFragments = new ArrayList<>();
        Fragment mTabShop = new FragmentShop();
        Fragment mTabTalk = new FragmentTalk();
        Fragment mTabOther = new FragmentOther();
        mFragments.add(mTabShop);
        mFragments.add(mTabTalk);
        mFragments.add(mTabOther);

        mAdapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragments.get(position);
            }

            @Override
            public int getCount() {
                return mFragments.size();
            }
        };

        mViewPager.setAdapter(mAdapter);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                int currentTab = mViewPager.getCurrentItem();
                setTab(currentTab);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        tab_shop.setOnClickListener(this);
        tab_talk.setOnClickListener(this);
        tab_other.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.id_tab_shop:
                setTab(0);
                break;
            case R.id.id_tab_talk:
                setTab(1);
                break;
            case R.id.id_tab_other:
                setTab(2);
                break;
        }
    }

    private void setTab(int currentTab) {
        tab_shop.setTextColor(Color.WHITE);
        tab_shop.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_profile_normal, 0, 0);
        tab_talk.setTextColor(Color.WHITE);
        tab_talk.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_message_normal, 0, 0);
        tab_other.setTextColor(Color.WHITE);
        tab_other.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_profile_normal, 0, 0);
        mViewPager.setCurrentItem(currentTab);
        switch (currentTab) {
            case 0:
                tab_shop.setTextColor(Color.rgb(240, 79, 158));
                tab_shop.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_profile_selected, 0, 0);
                break;
            case 1:
                tab_talk.setTextColor(Color.rgb(240, 79, 158));
                tab_talk.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_message_selected, 0, 0);
                break;
            case 2:
                tab_other.setTextColor(Color.rgb(240, 79, 158));
                tab_other.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_profile_selected, 0, 0);
                break;
        }
    }
}
