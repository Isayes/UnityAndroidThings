package com.company.usermanager.controll;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.usermanager.bean.User;
import com.company.usermanager.service.UserService;

@WebServlet("/user.do")
public class UserControll extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private UserService userService;

	@Override
	public void init() throws ServletException {
		userService = new UserService();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String a = request.getParameter("a");
		if (a == null) {
			return;
		} else if (a.equals("save")) {
			save(request, response);
		} else if (a.equals("list")) {
			list(request, response);
		} else if (a.equals("checklogin")) {
			checklogin(request, response);
		} else if (a.equals("delete")) {
			delete(request, response);
		} else if (a.equals("exit")) {
			request.getSession().removeAttribute("user");
			response.sendRedirect("login.jsp");
		}
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String id = request.getParameter("id");
		userService.delete(id);
		response.sendRedirect("user.do?a=list");

	}

	private void checklogin(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		// 先判断验证码
		String verifycode = (String) request.getSession().getAttribute("VerifyCode");
		String vc = request.getParameter("vc");

		if (!verifycode.equals(vc)) {
			request.getSession().setAttribute("errorMessage", "验证码错误！");
			response.sendRedirect("login.jsp");
			return;
		}

		User user = userService.checklogin(username, password);
		// response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		if (user != null) {
			request.getSession().setAttribute("user", user);
			response.sendRedirect("main.jsp");
		} else {
			// response.getWriter().println("<script>alert('用户名或密码错误!');location.href='login.jsp'</script>");
			// 有乱码问题需解决
			request.getSession().setAttribute("errorMessage", "用户名或密码错误!");
			response.sendRedirect("login.jsp");
		}
	}

	private void save(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		user.setUsername(request.getParameter("username"));
		user.setPassword(request.getParameter("password"));
		user.setRule(Integer.parseInt(request.getParameter("rule")));
		user.setDeptno(Integer.parseInt(request.getParameter("dept")));
		userService.save(user);
		response.sendRedirect("user.do?a=list");
	}

	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<User> list = userService.findAll();
		request.setAttribute("userList", list);

		request.getRequestDispatcher("list.jsp").forward(request, response);// 调度到jsp上

	}
}
