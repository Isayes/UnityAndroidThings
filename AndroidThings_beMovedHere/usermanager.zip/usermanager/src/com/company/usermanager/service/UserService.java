package com.company.usermanager.service;

import java.sql.SQLException;
import java.util.List;

import com.company.usermanager.bean.User;
import com.company.usermanager.dao.UserDAO;

/**
 * 业务逻辑
 * 
 * @author Administrator
 *
 */
public class UserService {

	private UserDAO userDao;

	public UserService() {

		userDao = new UserDAO();

	}

	public void save(User user) {
		try {
			userDao.insert(user);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<User> findAll() {
		List<User> list = null;
		try {
			list = userDao.select("");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public User checklogin(String username, String password) {

		String condition = " and username='" + username + "' and password='" + password + "'";
		List<User> list = null;
		try {
			list = userDao.select(condition);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list != null ? (list.size() > 0 ? list.get(0) : null) : null;
	}

	public void delete(String id) {

		try {
			userDao.delete(Integer.parseInt(id));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
