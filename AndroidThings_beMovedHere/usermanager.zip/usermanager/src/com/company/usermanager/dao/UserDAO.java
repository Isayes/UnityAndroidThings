package com.company.usermanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.company.usermanager.bean.User;
import com.company.usermanager.conn.DBConn;

/**
 * 
 * @author Administrator
 *
 */
public class UserDAO {

	private Connection conn;
	private PreparedStatement ps;
	private Statement st;
	private ResultSet rs;

	public UserDAO() {
		conn = DBConn.getConn();
	}

	public void insert(User user) throws SQLException {
		String sql = "insert into tbl_user values(null,?,?,?,?)";
		ps = conn.prepareStatement(sql);
		ps.setString(1, user.getUsername());
		ps.setString(2, user.getPassword());
		ps.setInt(3, user.getRule());
		ps.setInt(4, user.getDeptno());
		ps.executeUpdate();
		ps.close();
	}

	public List<User> select(String condition) throws SQLException {
		List<User> list = new ArrayList<>();
		String sql = "select * from tbl_user where 1=1" + condition;
		st = conn.createStatement();
		rs = st.executeQuery(sql);
		while (rs.next()) {
			User user = new User();
			user.setId(rs.getInt("id"));
			user.setUsername(rs.getString("username"));
			user.setPassword(rs.getString("password"));
			user.setRule(rs.getInt("rule"));
			user.setDeptno(rs.getInt("deptno"));
			list.add(user);
		}
		rs.close();
		st.close();
		return list;
	}

	public void delete(int id) throws SQLException {
		
		String sql = "delete from tbl_user where id=?";
		ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
	}

}
