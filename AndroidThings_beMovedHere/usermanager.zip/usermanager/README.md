# usermanager
Practice little Demo usermanager

##数据库表设计
![数据库表设计](https://raw.githubusercontent.com/Isayes/usermanager/73b1be48a47756e4871c50608f5f5d8869f80082/Pic/%E6%95%B0%E6%8D%AE%E5%BA%93.png)

##本练手项目初次效果演示
![效果演示](https://raw.githubusercontent.com/Isayes/usermanager/73b1be48a47756e4871c50608f5f5d8869f80082/Pic/%E7%BB%93%E6%9E%9C%E5%9B%BE%E6%BC%94%E7%A4%BA.gif)

##增加验证码功能后
先判断验证码正误，再进行用户名和密码判断，验证码区分大小写  
![增加验证码](https://github.com/Isayes/usermanager/blob/master/Pic/login%E5%A2%9E%E5%8A%A0%E9%AA%8C%E8%AF%81%E7%A0%81%E9%AA%8C%E8%AF%81%E5%8A%9F%E8%83%BD.png?raw=true)
